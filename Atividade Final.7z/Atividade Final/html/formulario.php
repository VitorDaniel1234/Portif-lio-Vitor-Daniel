<?php
// Configurações do banco de dados
$host = 'localhost';
$dbname = 'portfolio';
$username = 'root';
$password = '';
// Conexão com o banco de dados
try {
   $conn = new PDO("mysql:host=$host;dbname=$dbname", $username, $password);
   $conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
   // Captura os dados do formulário
   $nome = $_POST['nome'];
   $email = $_POST['email'];
   $mensagem = $_POST['mensagem'];
   // Prepara e executa o SQL de inserção
   $stmt = $conn->prepare("INSERT INTO mensagens (nome, email, mensagem) VALUES (:nome, :email, :mensagem)");
   $stmt->bindParam(':nome', $nome);
   $stmt->bindParam(':email', $email);
   $stmt->bindParam(':mensagem', $mensagem);
   $stmt->execute();
   echo "Mensagem enviada com sucesso!";
} catch (PDOException $e) {
   echo "Erro ao enviar a mensagem: " . $e->getMessage();
}
?>